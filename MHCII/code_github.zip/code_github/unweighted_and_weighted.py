# %%
import os
import numpy as np
import general_functions as gf
import matplotlib.pyplot as plt
from scipy.stats.stats import spearmanr
from sklearn import linear_model
from sklearn.model_selection import LeaveOneOut
import sys
import itertools
from datasets_git import dataset
from matplotlib.lines import Line2D

# %%
def plot_predictions(presentataion_profile,Y_s,proteins):
    markers = ["s","d","X","o","^","v","p"]
    colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'black']
    mc_list = list(itertools.product(markers, colors))
    fig = plt.figure(figsize=(10,6))
    Xs = []
    Ys = []
    
    for i,protein in enumerate(proteins):
        X = np.sum(presentataion_profile[protein])
        mkr, col = mc_list[i]            
        plt.plot(X,Y_s[i],label=protein,marker=mkr,color=col,ls="",markersize=12)
        Xs.append(X)
        Ys.append(Y_s[i])
    Xs = np.array(Xs)
    Ys = np.array(Ys)
    regr = linear_model.LinearRegression()
    regr.fit(Xs.reshape(-1,1),Ys.reshape(-1,1))
    y_pred = regr.predict(Xs.reshape(-1,1))
    plt.plot(Xs,y_pred,ls="--",color="black")
    plt.xlabel("Presentation score",size=15)
    plt.ylabel("Immunogenecity score",size=15)
    plt.grid(True)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5),prop={'size': 11.3})
    plt.tight_layout()
    return Xs,Ys



# %%
######################### Main information #########################
# 9-mer databases
path_to_IMGT_9_mers = "data/9_mers_IMGT_database.txt" # PATH TO IMGT 9-mer database
IMGT_9mers = gf.get_9_mer_lib(path_to_IMGT_9_mers)
distrobution_compare = sorted(IMGT_9mers.values())

# Global HLA
path_to_world_dist = "data/DRB_world_average.txt"
global_hla_dist = gf.read_world_average_DRB_dist(path_to_world_dist)

## ImmuneXperts dataset
# Paths needed for ImmuneXperts
IX_path_to_HLA_frequencies = "data/IX_HLA_frequencies.txt"
IX_path_to_fastas = "data/IX_fasta_sequences"
IX_path_to_netMHC_results = "data/netMHCIIpan_results_immuneXperts"
IX_path_protein_imm_results = "data/immuneXperts_imm_scores.txt"
IX = dataset(IX_path_to_HLA_frequencies, IX_path_to_fastas, IX_path_to_netMHC_results,IX_path_protein_imm_results, IMGT_9mers, distrobution_compare,verbose=True)
IX.proteins = [x for x in IX.proteins if x != "Hemocyanin"]
IX.Y = [IX.imm_scores[x] for x in IX.proteins]

## FDA dataset
# Loading the variables needed for a dataset
FDA_path_to_fastas = "data/FDA_fasta_sequences"
FDA_path_to_netMHC_results = "data/FDA_netMHCIIpan_results"
FDA_path_protein_imm_results = "data/FDA_imm_scores_independent.txt"
FDA = dataset(IX_path_to_HLA_frequencies,FDA_path_to_fastas,FDA_path_to_netMHC_results,FDA_path_protein_imm_results,IMGT_9mers,distrobution_compare,HLA_dist=global_hla_dist,verbose=True)

# %%
dataset = FDA
predictions_unweighted, Y = plot_predictions(dataset.presentation_profiles,dataset.Y,dataset.proteins)
predictions_weighted, Y = plot_predictions(dataset.weighted_presentation_profile,dataset.Y,dataset.proteins)

# %%
SCC,p_value = spearmanr(predictions_unweighted,Y)
SCC, p_value = round(SCC,2), round(p_value,2)
print(f"## Performance of the unweighted model: SCC {SCC}, p-value {p_value}")

# %%
SCC,p_value = spearmanr(predictions_weighted,Y)
SCC, p_value = round(SCC,3), round(p_value,2)
print(f"## Performance of the unweighted model: SCC {SCC}, p-value {p_value}")

# %%
