# %%
import os
import numpy as np
import general_functions as gf
import matplotlib.pyplot as plt
from scipy.stats.stats import spearmanr
from sklearn import linear_model
from sklearn.model_selection import LeaveOneOut
import sys
import itertools
from datasets_git import dataset
from matplotlib.lines import Line2D

# %%
def calculate_threeway_score_old(SB_results,proteins,Ys,distrobution_compare,HLA_freqs,IMGT_9mers,lower_threshold,upper_threshold):
    threeway_scores = []
    for i,protein in enumerate(proteins):
       #print(i,len(proteins))
        score_tracker = [0,0,0] # Foreign, self, treg
        for allele in SB_results[protein]:
            try:
                allele_freq = HLA_freqs[allele]
               # print(allele_freq)
            except KeyError:
                continue

            for epitope in SB_results[protein][allele]:
                binding_core = epitope[3]
                percentile_score = epitope[-1]

                if percentile_score > upper_threshold:
                    class_index = 2

                elif lower_threshold < percentile_score < upper_threshold:
                    class_index = 1

                else:
                    class_index = 0                    

                if allele[0:4] == "DRB1":
                    score_tracker[class_index] += allele_freq*9
                else:
                    score_tracker[class_index] += 0.2*allele_freq*9
        
        foreign_score, self_score, treg_score = score_tracker
        threeway_scores.append(foreign_score - treg_score)

    return threeway_scores

def find_best_threshold_old(dataset,proteins,Y,distrobution_compare):
    # Crating the unique percentile scores to iterate through
    unique_percentiles = dataset.unique_percentiles[1:] + [100]
    unique_percentiles = sorted(unique_percentiles)[::] #::i means step size 
    # Calculating the correlation matrix
    performance = [0 for _ in unique_percentiles]

    for j,upper_threshold in enumerate(unique_percentiles):
        # Because the index J is dependent on both how far i reached and how far j reached.
        three_way_score = calculate_threeway_score_old(dataset.SB_results,proteins,dataset.Y,distrobution_compare,dataset.HLA_freqs,IMGT_9mers,0,upper_threshold)        
        SCC = spearmanr(three_way_score,Y)[0]
        performance[j] = SCC
    # Analysing the correlaiton matrix
    matrix = np.array(performance)
    max_score = np.amax(matrix)
    max_indexes = np.where(matrix == np.amax(matrix))[0]
    optimal_thresholds = []
    for upper_index in max_indexes:
        optimal_thresholds.append([unique_percentiles[upper_index]])
    return optimal_thresholds,max_score,performance,unique_percentiles

def plot_training_curve(performance,unique_percentiles,skip):
    plt.plot(np.arange(len(performance)),performance)
    plt.xticks(np.arange(0,len(unique_percentiles),skip),unique_percentiles[::skip],rotation=90)
    plt.show()


def evaluate_thresholds(dataset,optimal_threshold,X_test,Y_test):
    all_scores = []
    for threshold in optimal_threshold:
        threeway_score = calculate_threeway_score_old(dataset.SB_results,X_test,Y_test,distrobution_compare,dataset.HLA_freqs,IMGT_9mers,0,threshold[0])
        all_scores.append(threeway_score[0])
    return np.mean(all_scores)


def calculate_running_median(seq,window):
    running_median = [x for x in seq]
    for i in range(len(seq)-window):
        running_median[i] = np.median(seq[i:i+window])
    return running_median


def plot_all_training_curve(SCC_curve,all_unique_percentiles,title):
    fig = plt.figure()
    list_of_percentiles = np.sort(np.concatenate(all_unique_percentiles, axis=0))
    list_of_percentiles = np.unique(list_of_percentiles)

    for curve,unique_percentiles in zip(SCC_curve,all_unique_percentiles):
        x_axis = [np.where(list_of_percentiles == x)[0][0] for x in unique_percentiles]
        running_median = calculate_running_median(curve,3)
        plt.plot(x_axis[1:],running_median[1:],color="red",alpha=0.7) # label="Running median",

    list_of_percentiles = [round(x,5) for x in list_of_percentiles]
    plt.xticks(np.arange(0,len(list_of_percentiles))[::3],list_of_percentiles[::3],rotation=90)
    plt.xlabel("Upper threshold",size=15)
    plt.ylabel("SCC",size=15)
    plt.ylim(-0.6,1)
    custom_lines = [Line2D([0], [0], color="red", lw=4)]
    plt.legend(custom_lines,["Running median"],loc='upper right')
    plt.title(title,size=16)
    plt.tight_layout()
    plt.show()


def leave_one_out_cross_validation(dataset):
    loo = LeaveOneOut()
    X_proteins = np.array(dataset.proteins)
    Y_imm = np.array(dataset.Y)
    X_s = []
    Y_s = []
    performance_curves = []
    all_unique_percentile = []
    for i,(train_index, test_index) in enumerate(loo.split(dataset.proteins)):
        print(f"Training fold {i+1} of {len(X_proteins)}")
        X_train, X_test = X_proteins[train_index], X_proteins[test_index]
        y_train, y_test = Y_imm[train_index], Y_imm[test_index]
        optimal_thresholds, max_score, performance, unique_percentiles = find_best_threshold_old(dataset,list(X_train),y_train,distrobution_compare)
        average_presnetataion_score_test = evaluate_thresholds(dataset,optimal_thresholds,X_test,y_test)
        X_s.append(average_presnetataion_score_test)
        Y_s.append(y_test[0])
        performance_curves.append(performance)
        all_unique_percentile.append(unique_percentiles)

    plot_all_training_curve(performance_curves,all_unique_percentile,"FDA training curves Model 1")
    return X_s,Y_s


def plot_LOO_predictions(dataset,X_s,Y_s,title):
    markers = ["s","d","X","o","^","v","p"]
    colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'black']
    mc_list = list(itertools.product(markers, colors))
    fig = plt.figure(figsize=(10,6))
    Xs = []
    Ys = []
    
    for i,protein in enumerate(dataset.proteins):
        mkr, col = mc_list[i]            
        plt.plot(X_s[i],Y_s[i],label=protein,marker=mkr,color=col,ls="",markersize=11)
        Xs.append(X_s[i])
        Ys.append(Y_s[i])
    
    Xs = np.array(Xs)
    Ys = np.array(Ys)
    regr = linear_model.LinearRegression()
    regr.fit(Xs.reshape(-1,1),Ys.reshape(-1,1))
    y_pred = regr.predict(Xs.reshape(-1,1))
    plt.plot(Xs,y_pred,ls="--",color="black")
    
    plt.xlabel("Adjusted presentation score",size=15)
    plt.ylabel("Immunogenecity score",size=15)
    plt.title(title,size=15)
    plt.xticks(size=13)
    plt.yticks(size=13)
    plt.grid(True)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5),prop={'size': 11.3})
    plt.tight_layout()


######################### Main information #########################
# 9-mer databases
path_to_IMGT_9_mers = "data/9_mers_IMGT_database.txt" # PATH TO IMGT 9-mer database
IMGT_9mers = gf.get_9_mer_lib(path_to_IMGT_9_mers)
distrobution_compare = sorted(IMGT_9mers.values())

# Global HLA
path_to_world_dist = "data/DRB_world_average.txt"
global_hla_dist = gf.read_world_average_DRB_dist(path_to_world_dist)

## ImmuneXperts dataset
# Paths needed for ImmuneXperts
IX_path_to_HLA_frequencies = "data/IX_HLA_frequencies.txt"
IX_path_to_fastas = "data/IX_fasta_sequences"
IX_path_to_netMHC_results = "data/netMHCIIpan_results_immuneXperts"
IX_path_protein_imm_results = "data/immuneXperts_imm_scores.txt"
IX = dataset(IX_path_to_HLA_frequencies, IX_path_to_fastas, IX_path_to_netMHC_results,IX_path_protein_imm_results, IMGT_9mers, distrobution_compare,verbose=True)
IX.proteins = [x for x in IX.proteins if x != "Hemocyanin"]
IX.Y = [IX.imm_scores[x] for x in IX.proteins]

## FDA dataset
# Loading the variables needed for a dataset
FDA_path_to_fastas = "data/FDA_fasta_sequences"
FDA_path_to_netMHC_results = "data/FDA_netMHCIIpan_results"
FDA_path_protein_imm_results = "data/FDA_imm_scores_independent.txt"
FDA = dataset(IX_path_to_HLA_frequencies,FDA_path_to_fastas,FDA_path_to_netMHC_results,FDA_path_protein_imm_results,IMGT_9mers,distrobution_compare,HLA_dist=global_hla_dist,verbose=True)

# %%
dataset = FDA 
X_validation,Y_validation = leave_one_out_cross_validation(dataset)
plot_LOO_predictions(dataset,X_validation,Y_validation,"FDA validation predictions Model 1")

# %%
SCC, p_value = spearmanr(X_validation,Y_validation)
SCC, p_value = round(SCC,2), round(p_value,2)
print(f"## Performance of thresholds on validation splits: SCC {SCC}, p-value {p_value}")

# %%
