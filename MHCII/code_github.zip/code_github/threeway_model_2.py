# %%
import os
import numpy as np
import general_functions as gf
import matplotlib.pyplot as plt
from scipy.stats.stats import spearmanr
from sklearn import linear_model
from sklearn.model_selection import LeaveOneOut
import sys
import itertools
from datasets_git import dataset
from matplotlib.lines import Line2D

# %%
def calculate_average_presentaion_score_left_out(presentation_profiles,percentile_profiles,treatment_ID,thresholds):
    presentaion_scores = []
    for threshold in thresholds:
        lower_threshold = threshold[0]
        upper_threshold = threshold[1]
        total_clasification_line = gf.calculate_classification_line_total(percentile_profiles[treatment_ID].copy(),lower_threshold,upper_threshold)
        theeway_score = gf.calculate_weighted_p_norm_2(presentation_profiles[treatment_ID].copy(),total_clasification_line.copy(),1)
        presentaion_scores.append(theeway_score)
        
    return np.mean(presentaion_scores)

def calculate_running_median(seq,window):
    running_median = [x for x in seq]
    for i in range(len(seq)-window):
        running_median[i] = np.median(seq[i:i+window])
    return running_median


def find_best_threshold(presentation_profiles,percentile_profiles,treatment_IDs,Y):
    # Crating the unique percentile scores to iterate through
    unique_percentiles = []
    for ID in treatment_IDs:
        for percentile_score in percentile_profiles[ID]:
            if percentile_score not in unique_percentiles:
                unique_percentiles.append(percentile_score)
    unique_percentiles = unique_percentiles + [100]
    lower_thresholds = sorted(unique_percentiles)[:1]
    unique_percentiles = sorted(unique_percentiles)[::] #::i means step size 
    # Calculating the correlation matrix
    matrix = [[0 for _ in unique_percentiles] for _ in unique_percentiles]
    for i,lower_threshold in enumerate(lower_thresholds):
        for j,upper_threshold in enumerate(unique_percentiles[i+1:]):
            # Because the index J is dependent on both how far i reached and how far j reached.
            j = i+1+j
            presentaion_scores = []
            for ID in treatment_IDs:
                total_clasification_line = gf.calculate_classification_line_total(percentile_profiles[ID].copy(),lower_threshold,upper_threshold)
                theeway_score = gf.calculate_weighted_p_norm_2(presentation_profiles[ID].copy(),total_clasification_line.copy(),1)
                presentaion_scores.append(theeway_score)
            SCC = spearmanr(presentaion_scores,Y)[0]
            matrix[i][j] = SCC
    # Analysing the correlaiton matrix
    matrix = np.array(matrix)
    max_score = np.amax(matrix)
    max_indexes = np.where(matrix == np.amax(matrix))
    optimal_thresholds = []
    for lower_index,upper_index in zip(max_indexes[0],max_indexes[1]):
        # print(unique_percentiles[lower_index],unique_percentiles[upper_index],distrobution_compare[int((unique_percentiles[lower_index]/100)*len(distrobution_compare))],distrobution_compare[int((unique_percentiles[upper_index]/100)*len(distrobution_compare))],max_score)
        optimal_thresholds.append([unique_percentiles[lower_index],unique_percentiles[upper_index]])
    return optimal_thresholds, max_score, matrix[0,:], unique_percentiles

def calculate_average_presentaion_score(presentation_profiles,percentile_profiles,treatment_IDS,Y,thresholds):
    presentaion_scores = []
    for i,threshold in enumerate(thresholds):
        presentaion_scores.append([])
        lower_threshold = threshold[0]
        upper_threshold = threshold[1]
        for ID in treatment_IDS:
            total_clasification_line = gf.calculate_classification_line_total(percentile_profiles[ID].copy(),lower_threshold,upper_threshold)
            theeway_score = gf.calculate_weighted_p_norm_2(presentation_profiles[ID].copy(),total_clasification_line.copy(),1)
            presentaion_scores[i].append(theeway_score)
    presentaion_scores = np.array(presentaion_scores)
    average_presentation_scores = np.mean(presentaion_scores,axis=0)
    return average_presentation_scores

def leave_one_out_predictions(presentation_profiles,percentile_profiles,treatment_IDS,Y):
    treatment_IDS = np.array(treatment_IDS)
    loo = LeaveOneOut()
    average_presentation_scores = []
    Ys = []
    optimal_thresholds_each_LOO = []
    learning_curves = []
    all_unique_percentiles = []
    for i,(train_index, test_index) in enumerate(loo.split(treatment_IDS)):
        print(f"{i+1}/{len(treatment_IDS)}")
        IDS_train, IDS_test = treatment_IDS[train_index], treatment_IDS[test_index]
        Y_train, Y_test = Y[train_index], Y[test_index]
        optimal_thresholds, max_score, learning_curve,unique_percentiles = find_best_threshold(presentation_profiles,percentile_profiles,IDS_train,Y_train)
        average_presentation_score = calculate_average_presentaion_score_left_out(presentation_profiles,percentile_profiles,IDS_test[0],optimal_thresholds)
        average_presentation_scores.append(average_presentation_score)
        optimal_thresholds_each_LOO.append(optimal_thresholds)
        learning_curves.append(learning_curve.tolist())
        Ys.append(Y_test[0])
        all_unique_percentiles.append(unique_percentiles)
    
    return np.array(average_presentation_scores),np.array(Ys),optimal_thresholds_each_LOO,learning_curves,all_unique_percentiles



def plot_presentation_scores_against_immunogenecity(presentataion_scores,Imm_scores,labels,title,outfile=None):
    markers = ["s","d","X","o","^","v","p"]
    colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'black']
    mc_list = list(itertools.product(markers, colors))
    fig = plt.figure(figsize=(10,6))
    Xs = []
    Ys = []
    
    for i in range(len(presentataion_scores)):
        if labels[i] != "TT":
            mkr, col = mc_list[i]            
            plt.plot(presentataion_scores[i],Imm_scores[i],label=labels[i],marker=mkr,color=col,ls="",markersize=11)
            Xs.append(presentataion_scores[i])
            Ys.append(Imm_scores[i])
    Xs = np.array(Xs)
    Ys = np.array(Ys)
    regr = linear_model.LinearRegression()
    regr.fit(Xs.reshape(-1,1),Ys.reshape(-1,1))
    y_pred = regr.predict(Xs.reshape(-1,1))
    plt.plot(Xs,y_pred,ls="--",color="black")
    
    plt.xlabel("Adjusted presentation score",size=15)
    plt.ylabel("Immunogenecity score",size=15)
    plt.title(title,size=15)
    plt.xticks(size=12)
    plt.yticks(size=12)
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5),prop={'size': 11.3})
    plt.grid(True)
    plt.tight_layout()
    if outfile:
        plt.savefig(title + ".png",bbox_inches='tight', dpi=150)
    else:
        plt.show()

def calculate_weighted_and_unweighted_scores(presentataion_profiles,weighted_presentataion_profiles,proteins,Y,treatment_IDs=None,save_predictions=None):
    presentataion_scores = []
    weighted_presentation_scores = []
    for protein in proteins:
        presentatiaon_score = np.sum(presentataion_profiles[protein])
        weighted_presentataion_score = np.sum(weighted_presentataion_profiles[protein])
        presentataion_scores.append(presentatiaon_score)
        weighted_presentation_scores.append(weighted_presentataion_score)
    

    if save_predictions is not None:
        save_file = open(save_predictions,"w+")
        for predictions, imm_score in zip(weighted_presentation_scores,Y):
            print(predictions,imm_score,sep="\t",file=save_file)


    print("Unweighted:",spearmanr(presentataion_scores,Y))
    print("Weighted:",spearmanr(weighted_presentation_scores,Y))


def plot_learning_curve(SCC_curve,all_unique_percentiles,title):
    fig = plt.figure()
    unique_xticks = set()
    list_of_percentiles = np.sort(np.concatenate(all_unique_percentiles, axis=0))
    list_of_percentiles = np.unique(list_of_percentiles)
    for curve,unique_percentiles in zip(SCC_curve,all_unique_percentiles):
        x_axis = [np.where(list_of_percentiles == x)[0][0] for x in unique_percentiles]
        percentile_thresholds = [round(x,5) for x in unique_percentiles]
        running_median = calculate_running_median(curve,5)
        plt.plot(x_axis[1:],running_median[1:],color="red",alpha=0.7) # label="Running median",
    

    list_of_percentiles = [round(x,5) for x in list_of_percentiles]
    plt.xticks(np.arange(0,len(list_of_percentiles))[:-1:10],list_of_percentiles[1::10],rotation=90)
    plt.xlabel("Thresholds",size=15)
    plt.ylabel("SCC",size=15)
    plt.ylim(-0.6,1)
    custom_lines = [Line2D([0], [0], color="red", lw=4)]
    plt.legend(custom_lines,["Running median"],loc='upper right')
    plt.title(title,size=16)
    plt.show()


# %%
######################### Main information #########################
# 9-mer databases
path_to_IMGT_9_mers = "data/9_mers_IMGT_database.txt" # PATH TO IMGT 9-mer database
IMGT_9mers = gf.get_9_mer_lib(path_to_IMGT_9_mers)
distrobution_compare = sorted(IMGT_9mers.values())

# Global HLA
path_to_world_dist = "data/DRB_world_average.txt"
global_hla_dist = gf.read_world_average_DRB_dist(path_to_world_dist)

## ImmuneXperts dataset
# Paths needed for ImmuneXperts
IX_path_to_HLA_frequencies = "data/IX_HLA_frequencies.txt"
IX_path_to_fastas = "data/IX_fasta_sequences"
IX_path_to_netMHC_results = "data/netMHCIIpan_results_immuneXperts"
IX_path_protein_imm_results = "data/immuneXperts_imm_scores.txt"
IX = dataset(IX_path_to_HLA_frequencies, IX_path_to_fastas, IX_path_to_netMHC_results,IX_path_protein_imm_results, IMGT_9mers, distrobution_compare,verbose=True)
IX.proteins = [x for x in IX.proteins if x != "Hemocyanin"]
IX.Y = [IX.imm_scores[x] for x in IX.proteins]

## FDA dataset
# Loading the variables needed for a dataset
FDA_path_to_fastas = "data/FDA_fasta_sequences"
FDA_path_to_netMHC_results = "data/FDA_netMHCIIpan_results"
FDA_path_protein_imm_results = "data/FDA_imm_scores_independent.txt"
FDA = dataset(IX_path_to_HLA_frequencies,FDA_path_to_fastas,FDA_path_to_netMHC_results,FDA_path_protein_imm_results,IMGT_9mers,distrobution_compare,HLA_dist=global_hla_dist,verbose=True)

# %%
# Main loop
dataset = IX
summary_tabel = []
treatment_IDS = np.array(dataset.proteins).copy()
Y = np.array(dataset.Y).copy()

average_presentation_scores,Ys,optimal_thresholds_each_LOO,learning_curves_LOO,all_unique_percentiles = leave_one_out_predictions(dataset.presentation_profiles,dataset.percentile_profiles,treatment_IDS,Y)
SCC_LOO,p_value = spearmanr(average_presentation_scores,Ys)
plot_learning_curve(learning_curves_LOO,all_unique_percentiles,f"IX training curves Model 2")
# Plotting Roche predictions
plot_presentation_scores_against_immunogenecity(average_presentation_scores,Ys,treatment_IDS,"ImmuneXperts validation predictions Model 2")
# %%
SCC, p_value = round(SCC_LOO,2), round(p_value,2)
print(f"## Performance of thresholds on validation splits: SCC {SCC}, p-value {p_value}")