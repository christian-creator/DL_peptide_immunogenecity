Code used to generate results presented in project: "Predicting protein drug immunogenicity"

Short description of each script
- datasets_git.py: Contains a class object which is used to store varius features of each dataset like the HLA distrobution it uses, the netMHCIIpan results, protein_sequences and immunogencity scores. Furthermore, it is used to calculate the presentation profiles, weighted presentataion profiles and used to calculate the percentile score of all MHCII ligands.
- general_functions_git.py: A script containing a library of functions used throughout the project. 
- threeway_model_1.py: Is the script used to generate the results from the first vairation of the three-way model. (The older version of the model).
- threeway_model_1.py: Is the script used to generate the results from the second vairation of the three-way model. (The newer version of the model)
- unweighted_and_weighted.py: Is the script used to calcualte the weighted and unweighted presentataion scores for the proteins and plot them.
Most of these scripts are somewhat slow because it needs to calculate the percentile score alot of MHCII ligands in a huge distrobution. Can be made faster.


Folders:
- data: All of the data used to generate the results of the project
- Other_scripts: Filtering the IMGT database and replacing C with Xs