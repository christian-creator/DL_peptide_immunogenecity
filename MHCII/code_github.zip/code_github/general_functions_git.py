import os
import sys
import numpy as np
import pandas as pd

def new_percentile_score(liste,score):
    lower = 0
    upper = len(liste)-1
    # print("Start")
    while lower <= upper:
        index = int((lower+upper)/2)
        if liste[index] < score:
            lower = index + 1
        elif liste[index] > score:
            upper = index - 1
        else:
            possible = liste[index]
            while possible == score:
                if index == 0:
                    return 0 
                index -= 1 
                possible = liste[index]
            return index/len(liste)*100
    if index + 1 < len(liste):
        possible = liste[index + 1]
    else:
        possible = liste[index - 1]
    while possible > score:
        if index == 0:
            return 0
        index -= 1 
        possible = liste[index]
    return index/len(liste)*100

def get_sequences(path_to_fastas):
    sequences = dict()
    for file in os.listdir(path_to_fastas):
        protein = file[:-6]
        sequences[protein] = dict()
        fasta_file = open(path_to_fastas + "/" + file, "r")
        for line in fasta_file:
            if line[0] == ">":
                chain_header = line[1:].strip()
                chain_header = chain_header.split("|")[0].strip()
                sequences[protein][chain_header] = ""
            else:
                sequences[protein][chain_header] += line.strip()
    return sequences

def get_HLA_freqs(path_to_HLA_frequencies):
    """Getting the frequencies of the HLA molecules in the In vitro dataset

    Args:
        path_to_HLA_frequencies (str): path to the frequencies

    Returns:
        dict: HLA with it's frequency
    """
    HLA_freqs = dict()
    infile = open(path_to_HLA_frequencies, "r")
    for line in infile:
        line = line.split()
        allele = line[0]
        freq = float(line[1])
        HLA_freqs[allele] = freq
    return HLA_freqs

def get_9_mer_lib(path_to_ninemers):
    """Creates the 9mer libaries used to create the toll profiles. Takes in the results from fasta2pep and creates dictionary with the libary

    Args:
        path_to_ninemers (str): path to results from fasta2pep

    Returns:
        dict: key is 9mer and value is the count of occurences
    """
    infile = open(path_to_ninemers,"r")
    lib = dict()
    for line in infile:
        line = line.split()
        nine_mer = line[0]
        if nine_mer not in lib.keys():
            lib[nine_mer] = 1
        else:
            lib[nine_mer] += 1
    return lib

def read_results_files(path_to_results,proteins):
    """Reading the results derived from the netMHCIIpan output and returns a directory of 
        the epitopes with the general structure: data[protein][allele] = [epitope,epitope]

    Args:
        path_to_results (str): Path to the netMCHIIpan results
        proteins (list): list of proteins

    Returns:
        dict,dict: The results saved in a SB and WB dict
    """

    # The dataframes
    SB_score = dict()
    WB_score = dict()
    for protein in proteins:
        results_files = [x for x in os.listdir(path_to_results) if protein == x.split(".")[1]]
        SB_score[protein] = dict()
        WB_score[protein] = dict()
        # For every file in the results_files containing the different lengths
        for file in results_files:
            infile = open(path_to_results + "/" + file, "r")
            for line in infile:
                line = line.split()
                if len(line) > 1:
                    if line[1] == "Allele:":
                        allele = line[-1]
                    elif line[-1] == "<=WB":
                        if allele not in WB_score[protein].keys():
                            # [pos,peptide,of,core,identity, binding_score]
                            WB_score[protein][allele] = [[int(line[0]), line[2], int(line[3]), line[4], line[6], line[8]]]
                        else:
                            # [pos,peptide,of,core,identity, binding_score]
                            WB_score[protein][allele].append([int(line[0]), line[2], int(line[3]), line[4], line[6], line[8]])
                    elif line[-1] == "<=SB":
                        if allele not in SB_score[protein].keys():
                            # [pos,peptide,of,core,identity, binding_score]
                            SB_score[protein][allele] = [[int(line[0]), line[2], int(line[3]), line[4], line[6], line[8]]]
                        else:
                            # [pos,peptide,of,core,identity, binding_score]
                            SB_score[protein][allele].append([int(line[0]), line[2], int(line[3]), line[4], line[6], line[8]])
    return SB_score, WB_score


def calculate_epitope_profiles_based_on_binding(SB_score, WB_score, sequences, protein, HLA_freqs,WB_threshold=None,SB_threshold=None,core=False,alleles=False):
    """From the NETMHCIIpan results the function creates SB profiles where we can see the sum of presentations 
       scores in the different regions of the proteins. 

    Args:
        SB_score (dict): The SB results from netMHCIIpan
        sequences (The fasta sequences of the proteins): The fasta sequences of the proteins
        protein (list): List of proteins 
        HLA_freqs (dict): The frequencies of the HLA in teh in vitro assay
        WB_threshold (int): The threshold the binding score has to be above before getting deemed WB
        SB_threshold (int): The threshold the binding score has to be above before getting deemed WB
        core (bool, optional): Do you want to analyze the entire epitopes or only the binding cores?. Defaults to False.

    Returns:
        dict: The epitope profiles SB_profile, WB_profile
    """
    # Create epitope profile dataframe
    SB_epitope_profile = dict()
    for chain in sequences[protein].keys():
        SB_epitope_profile[chain] = [0]*len(sequences[protein][chain])

    # SB scores
    if alleles:
        all_allleles = alleles
    else:
        all_allleles = SB_score.keys()

    for allele in all_allleles:
        try:
            allele_freq = HLA_freqs[allele]
        except KeyError:
            continue

        try:
            SB_score[allele]
        except KeyError:
            continue

        for epitope in SB_score[allele]:                
            # Checking if the binding score is above or below the threshold
            if SB_threshold:
                if float(epitope[-1]) > SB_threshold:
                    continue
            for protein_chain in SB_epitope_profile.keys():
                if epitope[-2].split("|")[0] in protein_chain:
                    # Verify if we use the entire epitope or only the core.
                    if core is False: 
                        pos = epitope[0] - 1
                        length = len(epitope[1])
                    else:
                        pos = epitope[0] + epitope[2] - 1
                        length = len(epitope[3])
                    # Add the scores to the correct postions
                    for i in range(length):
                        # J is the postion in the chain where the epitope is located
                        j = pos + i
                        # Adding the frequencies
                        if allele[0:4] == "DRB1":
                            SB_epitope_profile[protein_chain][j] += allele_freq
                        else:
                            SB_epitope_profile[protein_chain][j] += 0.2*allele_freq
    return SB_epitope_profile

def get_total_epitope_profile(dictionary,order_of_keys):
    """Takes SB profiles distrubuted on the chains and collects them in one list

    Args:
        dictionary (dict): SB or WB profiles
        order_of_keys (list): How should the scores be aranged

    Returns:
        list: total SB or WB profiles aranged using the order of keys
    """
    total = []
    for key in order_of_keys:
        total += dictionary[key]
    return total

def calculate_toll_profiles_2(SB_results_original,sequences,IMGT_9mers,protein,fivemer=None):
    """Calulates the "tolerization" profile based on the presented peptides. This is acheived


    Args:
        SB_results_original (dict): Dictionary containing the epitopes found by NetMHCIIpan
        sequences (dict): Dictionary containing the sequences for all proteins divided by their chains
        IMGT_9mers (dict): Dictionary containing the 9-mers found in the IMGT database with their frequency
        protein (str): The protein the toll-profile should be calculated for

    Returns:
        dict: Dictionary containing the toll-profile for each chain
    """
    toll_line = dict()
    epitopes_presented = []
    for allele in SB_results_original[protein].keys():
        for epitope in SB_results_original[protein][allele]:
            chain_epitope = epitope[4]
            position = epitope[0] + epitope[2] - 1
            nine_mer = epitope[3]
            if fivemer:
                peptide = remove_anchor_positions(nine_mer)
            else:
                peptide = nine_mer


            chain_found = False 
            for chain_protein in sequences[protein].keys():
                if chain_epitope in chain_protein or chain_protein in chain_epitope:
                    chain_found = chain_protein
            try:
                self_similarity_score = IMGT_9mers[peptide]

            except KeyError:
                self_similarity_score = 0

            if chain_found is False:
                print(protein, chain_epitope,SB_results_original[protein].keys())
                print("Kan ikke finde protein navnet i netMHCIIpan resultater og sekvenser")
                sys.exit(1)
            
            epitope_data = [position,chain_found,self_similarity_score]

            if epitope_data not in epitopes_presented:
                epitopes_presented.append(epitope_data)
    
    for chain in sequences[protein].keys():
        toll_line[chain] = [0]*len(sequences[protein][chain])

    for epitope in epitopes_presented:
        position = epitope[0]
        chain_found = epitope[1]
        percentile_score = epitope[2]
        for i in range(9):
                j = position + i
                toll_line[chain_found][j] += percentile_score
    
    return toll_line

def remove_anchor_positions(ninemer):
    """Removes the anchor positions form a 9-mer. Here the anchor positons are defined as 1,4,6,9 found from https://pubmed.ncbi.nlm.nih.gov/12207335/.

    Args:
        ninemer (str): 9mer

    Returns:
        str: 5mer
    """
    return "".join([aa for i,aa in enumerate(ninemer) if (i+1) not in [1,4,6,9]])

def get_5mers_from_9mers(IMGT_9mers,presented_ninemers_IMGT):
    IMGT_5mers = dict()
    for ninemer in IMGT_9mers.keys():
        if ninemer in presented_ninemers_IMGT:
            fivemer = remove_anchor_positions(ninemer)
            if fivemer not in IMGT_5mers.keys():
                IMGT_5mers[fivemer] = IMGT_9mers[ninemer]
            else:
                IMGT_5mers[fivemer] += IMGT_9mers[ninemer]
    return IMGT_5mers


def calculate_percentile_line(SB_results_original,sequences,IMGT_9mers,distrobution_compare,protein,fivemer=None):
    percentile_line = dict()
    for chain in sequences[protein].keys():
        percentile_line[chain] = [[]]*len(sequences[protein][chain])
    
    for allele in SB_results_original.keys():
        for epitope in SB_results_original[allele]:
            pos = epitope[0]
            off = epitope[2]
            nine_mer = epitope[3]
            chain_epitope = epitope[4]
            for chain_protein in percentile_line.keys():
                if chain_epitope in chain_protein or chain_protein in chain_epitope:
                    chain_found = chain_protein
            try:
                if fivemer:
                    peptide = remove_anchor_positions(nine_mer.replace("X","C"))
                else:
                    peptide = nine_mer.replace("X","C")
                percentile_score = IMGT_9mers[peptide]
            except KeyError:
                percentile_score = 0
            for i in range(9):
                j = pos + off + i - 1
                percentile_line[chain_found][j] = percentile_line[chain_found][j] + [percentile_score]
    
    for chain in percentile_line.keys():
        for i in range(len(percentile_line[chain])):
            if len(percentile_line[chain][i]) > 0:
                percentile_line[chain][i] = new_percentile_score(distrobution_compare,np.mean(percentile_line[chain][i]))
            else:
                percentile_line[chain][i] = 0
    

    return percentile_line

def calculate_classification_line(percentile_line,lower_threshold,upper_threshold):
    clasification_line = dict()
    for chain in percentile_line.keys():
        clasification_line[chain] = percentile_line[chain].copy()
        for i,percentile_score in enumerate(clasification_line[chain]):
            if percentile_score >= upper_threshold:
                clasification_line[chain][i] = -1
            elif percentile_score <= lower_threshold:
                clasification_line[chain][i] = 1
            else:
                clasification_line[chain][i] = 0
    return clasification_line


def calculate_classification_line_total(percentile_line_total,lower_threshold,upper_threshold):
    clasification_line = percentile_line_total.copy()
    for i,percentile_score in enumerate(clasification_line):
            if percentile_score >= upper_threshold:
                clasification_line[i] = -1
            elif percentile_score <= lower_threshold:
                clasification_line[i] = 1
            else:
                clasification_line[i] = 0
    return clasification_line

def calculate_weighted_p_norm_2(presentation_profile,classification_profile,n):
    return np.sum([(presentation_profile[i]**n)*classification_profile[i] for i in range(len(presentation_profile))])

def calcualte_weighted_epitope_profiles(total_SB_profile,total_toll_profile):
    weights = [0 if x > 0 else 1 for x in total_toll_profile]
    total_SB_profile = [total_SB_profile[i]*weights[i] for i in range(len(total_SB_profile))]
    return total_SB_profile

def calcualte_presentation_profile_removing_self(SB_score, sequences, protein, HLA_freqs, IMGT_database, SB_threshold=None, core=False, alleles=False):
    """From the NETMHCIIpan results the function creates SB profiles where we can see the sum of presentations 
       scores in the different regions of the proteins. 

    Args:
        SB_score (dict): The SB results from netMHCIIpan
        sequences (The fasta sequences of the proteins): The fasta sequences of the proteins
        protein (list): List of proteins 
        HLA_freqs (dict): The frequencies of the HLA in teh in vitro assay
        WB_threshold (int): The threshold the binding score has to be above before getting deemed WB
        SB_threshold (int): The threshold the binding score has to be above before getting deemed WB
        core (bool, optional): Do you want to analyze the entire epitopes or only the binding cores?. Defaults to False.

    Returns:
        dict: The epitope profiles SB_profile, WB_profile
    """
    # Create epitope profile dataframe
    SB_epitope_profile = dict()
    for chain in sequences[protein].keys():
        SB_epitope_profile[chain] = [0]*len(sequences[protein][chain])

    # SB scores
    if alleles:
        all_allleles = alleles
    else:
        all_allleles = SB_score.keys()

    for allele in all_allleles:
        try:
            allele_freq = HLA_freqs[allele]
        except KeyError:
            continue

        try:
            SB_score[allele]
        except KeyError:
            continue


        for epitope in SB_score[allele]:
            try:
                IMGT_database[epitope[3]]
                continue 
            except KeyError:
                pass
            for protein_chain in SB_epitope_profile.keys():
                if epitope[-2].split("|")[0] in protein_chain:
                    # Verify if we use the entire epitope or only the core.
                    if core is False: 
                        pos = epitope[0] - 1
                        length = len(epitope[1])
                    else:
                        pos = epitope[0] + epitope[2] - 1
                        length = len(epitope[3])
                    # Add the scores to the correct postions
                    for i in range(length):
                        # J is the postion in the chain where the epitope is located
                        j = pos + i
                        # Adding the frequencies
                        if allele[0:4] == "DRB1":
                            SB_epitope_profile[protein_chain][j] += allele_freq
                        else:
                            SB_epitope_profile[protein_chain][j] += 0.2*allele_freq
    return SB_epitope_profile


def calculate_imm_score(SB_results,HLA_freq_dist,protein,lower_threshold,upper_threshold):
    score = 0
    zero_score = 0
    for allele in SB_results[protein].keys():
        if allele not in HLA_freq_dist.keys():
            continue
        for epitope in SB_results[protein][allele]:
            percentile_score = epitope[-1]
            if percentile_score >= upper_threshold:
                if "DRB1" in allele:
                    score -= HLA_freq_dist[allele] * 9
                else:
                    score -= (HLA_freq_dist[allele] * 9)* 0.2 

            elif percentile_score <= lower_threshold:
                if "DRB1" in allele:
                    score += HLA_freq_dist[allele]*9
                else:
                    score += (HLA_freq_dist[allele] * 9)* 0.2 
            else:
                if "DRB1" in allele:
                    zero_score += HLA_freq_dist[allele]*9
                else:
                    zero_score += (HLA_freq_dist[allele] * 9)* 0.2 
    return score

def find_optimal_cutoff_thresholds(SB_results_with_percentile,proteins,treatment_IDS,HLA_freqs,unique_percentiles,Y):
    lower_threshold, upper_threshold = 0, 99.9437
    for i,lower_threshold in enumerate(unique_percentiles):
        for j,upper_threshold in enumerate(unique_percentiles[i+1:]):
            predicted_scores = []
            for z,ID in enumerate(treatment_IDS):
                predicted_imm_score = calculate_imm_score(SB_results_with_percentile,HLA_freqs[ID],proteins[z],lower_threshold, upper_threshold)
                predicted_scores.append(predicted_imm_score)


def load_proteins_and_immscores(path_to_protein_list):
    infile = open(path_to_protein_list,"r")
    proteins = []
    imm_scores = dict()
    for line in infile:
        line = line.split()
        protein = line[0]
        imm_score = int(line[1])
        proteins.append(protein)
        imm_scores[protein] = imm_score
    return proteins,imm_scores

def get_presented_peptides_9mers(path_to_presented_peptides_in_IMGT):
    presented_partion_files = os.listdir(path_to_presented_peptides_in_IMGT)
    presented_9mers = set()
    for partion in presented_partion_files:
        path_to_partion = os.path.join(path_to_presented_peptides_in_IMGT,partion)
        partion_file = open(path_to_partion,"r")
        for line in partion_file:
            line = line.split()
            if len(line) > 0:
                if line[-1] == "<=SB":
                    ninemer = line[4]
                    if ninemer not in presented_9mers:
                        presented_9mers.add(ninemer)
    return presented_9mers


def read_world_average_DRB_dist(path_to_world_dist):
    infile = open(path_to_world_dist,"r")
    frequencies = dict()
    for line in infile:
        if line[0] == "#":
            continue
        line = line.split()
        if len(line) > 1:
            frequencies[line[0]] = float(line[1])
    return frequencies


if __name__ == "__main__":
    path_to_world_dist = "data/DRB_world_average.txt"
    read_world_average_DRB_dist(path_to_world_dist)



