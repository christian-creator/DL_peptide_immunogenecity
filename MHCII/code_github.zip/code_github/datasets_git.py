# %%
import os
import numpy as np
import general_functions_git as gf
import sys
import itertools
import random

class dataset():
    """Construction of dataset for easier usage and better control of variables specific for different datasets
    """

    def __init__(self, path_HLA_freq, path_to_fastas, path_to_netMHC_results, path_protein_imm_results, IMGT_9mers=None, distrobution_compare=None,HLA_dist=None,random_self=False,verbose=False):
        if verbose:
            print("## Loading dataset")
        self.path_HLA_freq = path_HLA_freq
        self.path_to_fastas = path_to_fastas
        self.path_to_netMHC_results = path_to_netMHC_results
        self.path_protein_imm_results = path_protein_imm_results
        self.IMGT_9mers = IMGT_9mers
        self.distrobution_compare = distrobution_compare

        # Loading the specific things
        self.proteins, self.imm_scores = self.read_proteins_and_immscores(
            path_protein_imm_results)
        
        if HLA_dist:
            self.HLA_freqs = HLA_dist
        else:
            self.HLA_freqs = gf.get_HLA_freqs(path_HLA_freq)

        self.Y = np.array([self.imm_scores[protein]
                          for protein in self.proteins])

        self.sequences = gf.get_sequences(path_to_fastas)
        print("## Reading SB results from NetMHCIIpan")
        self.SB_results, self.WB_results = gf.read_results_files(path_to_netMHC_results, self.proteins)
        if IMGT_9mers:
            if verbose:
                print("## Calculating percentile line")
            self.presentation_profiles, self.percentile_profiles, self.SB_results = self.get_presentaion_and_percentile_lines(
                self.proteins, self.SB_results, self.WB_results, self.HLA_freqs, self.sequences, IMGT_9mers, distrobution_compare, fivemer=None)
            # The presentatiaon profile for the two-way model
            self.weighted_presentation_profile = self.get_weighted_presentataion_profile(self.proteins, self.SB_results, self.WB_results, self.HLA_freqs, self.sequences, IMGT_9mers)
        if verbose:
            print("## Calculating percentile score for all predicted MHCII ligands")
        self.unique_percentiles = self.assign_percentile_scores_to_MHCII_ligands(random_self=random_self,v=verbose)

    def read_proteins_and_immscores(self, path_to_proteins_imm_scores):
        infile = open(path_to_proteins_imm_scores, "r")
        imm_scores = dict()
        for line in infile:
            line = line.split()
            if len(line) > 0:
                protein = line[0]
                imm_score = int(line[1])
                imm_scores[protein] = imm_score
        return list(imm_scores.keys()), imm_scores

    def get_presentaion_and_percentile_lines(self, proteins, SB_results, WB_results, HLA_freqs, sequences, IMGT_9mers, distrobution_compare, fivemer=None):
        presentation_profiles = dict()
        percentile_profiles = dict()
        for i, protein in enumerate(proteins[:]):
            order_of_keys = sorted(sequences[protein].keys())
            SB_profile = gf.calculate_epitope_profiles_based_on_binding(
                SB_results[protein], WB_results[protein], sequences, protein, HLA_freqs, core=True)
            SB_total = gf.get_total_epitope_profile(SB_profile, order_of_keys)
            percentile_line = gf.calculate_percentile_line(SB_results[protein], sequences, IMGT_9mers, distrobution_compare, protein, fivemer=fivemer)
            percentile_line_total = gf.get_total_epitope_profile(percentile_line, order_of_keys)
            presentation_profiles[protein] = SB_total
            percentile_profiles[protein] = percentile_line_total
        return presentation_profiles, percentile_profiles,SB_results
    
    def get_weighted_presentataion_profile(self, proteins, SB_results, WB_results, HLA_freqs, sequences, IMGT_9mers):
        presentation_profiles = dict()
        for i, protein in enumerate(proteins[:]):
            order_of_keys = sorted(sequences[protein].keys())
            SB_weighted_profile = gf.calcualte_presentation_profile_removing_self(SB_results[protein], sequences, protein, HLA_freqs,IMGT_9mers, core=True)
            SB_weighted_total = gf.get_total_epitope_profile(SB_weighted_profile, order_of_keys)
            presentation_profiles[protein] = SB_weighted_total
        return presentation_profiles

    def assign_percentile_scores_to_MHCII_ligands(self,random_self=False,v=False):
        unique_percentiles = []
        for i,protein in enumerate(self.proteins):
            if v:
                print("## Progress of assigning perceintile scores",i + 1,len(self.proteins))
            for j,allele in enumerate(self.SB_results[protein].keys()):
                if allele not in  self.HLA_freqs.keys():
                    continue

                for epitope in self.SB_results[protein][allele]:
                    binding_core = epitope[3]
                    if random_self is not True:
                        try:
                            self_similiarity_score = self.IMGT_9mers[binding_core]
                        except KeyError:
                            self_similiarity_score = 0
                    else:
                        # Get random score between 0 and maximum in the distrobution
                        self_similiarity_score = random.randint(0,self.distrobution_compare[-1])
                    
                    if self_similiarity_score != 0:
                        percentile_score = gf.new_percentile_score(self.distrobution_compare,self_similiarity_score)
                        unique_percentiles.append(percentile_score)
                        epitope.append(percentile_score)
                        
                    else:
                        epitope.append(0)

        unique_percentiles = set(unique_percentiles)
        return sorted([x for x in unique_percentiles])

# %%
