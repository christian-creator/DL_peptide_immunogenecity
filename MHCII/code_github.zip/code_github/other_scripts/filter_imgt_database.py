import os
import sys
import math


def analyze_keyword(entry,include_filter, exclude_filter):
    """Check if the entry does not include synthetic constructs using the exclude filter


    Args:
        entry (str): A single entry extracted from the entire .dat file
        include_filters (list): A list of the keywords which must be present in the entry
        exclude_filter (list): A list of kewywords which must not be present in the entry

    Returns:
        bool: Statement on whether the entry fills the requirements
    """
    include_flag = False
    exclude_flag = False
    for line in entry.split("\n"):
        # print(line)
        line_split = line.split()
        if len(line_split) >=1:
            if line_split[0] == "KW":
                # Check if keywords are found in include filter 
                if any([x in line for x in include_filter]):
                    include_flag = True
                # Check if keywords are found in exclude filter 
                if any([x in line for x in exclude_filter]):
                    exclude_flag = True
                # print(include_flag,exclude_flag)
    if include_flag and not exclude_flag:
        return True
    else:
        return False

def extract_protein_sequence(entry,ID):
    """Extract the longest protein sequence from the entry using the FT tags and the \traslation= flag.

    Args:
        entry (str): A single entry extracted from the entire .dat file

    Returns:
        str: The protein sequence
    """
    entry_sequence = ""
    translation_flag = False
    aa_seq = ""
    for line in entry.split("\n"):
        line_split = line.split()
        if len(line_split) > 1:
            if line_split[0] == "FT":
                if "/translation=\"" in line_split[1]:
                    if "\"" not in line_split[1].replace("/translation=\"",""):
                        aa_seq += line_split[1].replace("/translation=\"","").strip()
                        translation_flag = True
                    else:
                        if len(line_split[1].replace("/translation=\"","")[:-1]) > len(entry_sequence):
                            entry_sequence = line_split[1].replace("/translation=\"","")[:-1]
                elif translation_flag is True:
                    if "\"" not in line_split[1]:
                        aa_seq += line_split[1].strip()
                    else:
                        aa_seq += line_split[1].strip()[:-1]
                        translation_flag = False
                        if len(aa_seq) > len(entry_sequence):
                            entry_sequence = aa_seq
    return entry_sequence

def apply_hobohm(infile_name, outfile_name):
    os.system("fastasort FASTAFILE | ffastauniq -fm 2 —")

def find_gap_domain_tag(entry):
    EBML_ALIGN_FLAG = False
    for line in entry.split("\n"):
        line_split = line.split()
        if len(line_split) > 1:
            if line_split[0] == "DR":
                if "EMBL-" in line:
                    EBML_ALIGN_FLAG = True
    return EBML_ALIGN_FLAG
                

def main_loop(outfile_name,domain_tag=False):
    # Path to raw IMGT file        
    path_to_imgt_file = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/raw/imgt.dat"
    # path_to_imgt_file = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/raw/sample_database.dat"
    imgt_file = open(path_to_imgt_file,"r")
    number_of_lines_in_file = len(open(path_to_imgt_file).readlines())

    # Name and creation of outfiles
    outfile_clean_database_name = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/clean/before_redundancy/{}.dat".format(outfile_name)
    outfile_fasta_file_name =  "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/clean/before_redundancy/{}.fasta".format(outfile_name)
    outfile_clean_database = open(outfile_clean_database_name,"w+")
    outfile_fasta_file = open(outfile_fasta_file_name,"w+")

    # Filters
    include_filter = ["immunoglobulin (IG)","T cell receptor (TR)"]
    exclude_filter = ["artificial", "Chimeric", "Patent", "engineered", "Altered", "synthetic", "Recombinant"]

    # Iterate through the IMGT.dat file
    entry = ""
    species_flag = False
    for i,line in enumerate(imgt_file):
        # Progress tracking
        if i%int(number_of_lines_in_file/10) == 0:
            print(math.ceil(i/number_of_lines_in_file*100),"%")
        
        line_split = line.strip().split()
        if len(line_split) >= 1:
            if line_split[0] == "ID":
                ID = line_split[1]
            if line_split[0] == "OS" and not species_flag:
                species = " ".join(line_split[1:])
                species_flag = True
            if line_split[0] != "//":
                entry += line
            else:
                if analyze_keyword(entry,include_filter,exclude_filter):
                    peptide_sequence = extract_protein_sequence(entry,ID)
                    if domain_tag:
                        if find_gap_domain_tag(entry):
                            if len(peptide_sequence) >= 1:
                                if "Homo".lower() in species.lower():
                                    print(">{}".format(ID),file=outfile_fasta_file)
                                    print(peptide_sequence,file=outfile_fasta_file)
                                    print(entry,file=outfile_clean_database)
                                    print("//",file=outfile_clean_database)
                    else:
                        if len(peptide_sequence) >= 1:
                            if "Homo".lower() in species.lower():
                                print(">{}".format(ID),file=outfile_fasta_file)
                                print(peptide_sequence,file=outfile_fasta_file)
                                print(entry,file=outfile_clean_database)
                                print("//",file=outfile_clean_database)
                entry = ""
                species = ""
                species_flag = False

main_loop("filtered_GAP_DOMAIN_tag",domain_tag=True)