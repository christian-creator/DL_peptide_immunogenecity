import sys

def read_query_database(path_to_query_database):
    infile = open(path_to_query_database,"r")
    db = dict()
    for line in infile:
        if line[0] == ">":
            header = line[1:].strip()
            db[header] = ""
        else:
            db[header] += line.strip()
    return db

def read_blast_results(path_to_blast_results):
    blast_results_file = open(path_to_blast_results,"r")
    blast_results = dict()
    for line in blast_results_file:
        line = line.split()
        query_id = line[0]
        e_value = float(line[-2])
        if query_id not in blast_results.keys():
            blast_results[query_id] = [e_value]
        else:
            blast_results[query_id].append(e_value)
    return blast_results

def filter_database(query_db,blast_results,path_clean_database=None,threshold=0.05):
    if path_clean_database:
        outfile = open(path_clean_database,"w+")
    in_germline = 0
    not_germline = 0
    for ID in query_db.keys():
        try:
            germline_check = any([x < threshold for x in blast_results[ID]])
        except KeyError:
            continue
        if germline_check:
            in_germline += 1
            if path_clean_database:
                print(">"+ID,file=outfile)
                print(query_db[ID],file=outfile)

        else:
            not_germline += 1
    print(in_germline,not_germline)

path_to_query_database = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/clean/after_redundancy/filtered_IMGT_ALL.fasta"
path_to_blast_results = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/blast_results/blast_filtered_against_germline_total.results"
path_to_clean_database = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/clean/after_redundancy/filtered_IMGT_ALL_germline_filtered_v_exon.fasta"

query_db = read_query_database(path_to_query_database)
blast_results = read_blast_results(path_to_blast_results)
filter_database(query_db,blast_results,threshold=10**-41)
