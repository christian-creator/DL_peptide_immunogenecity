import os
import sys

def read_fasta_files(file_path):
    infile = open(file_path,"r")
    data = dict()
    for line in infile:
        if line[0] == ">":
            header = line.strip()
            data[header] = ""
            
        elif line[0] != ">" and len(line) > 0:
            data[header] += line.replace("C","X")
    infile.close()
    return data

        
def write_fasta_file(file_path,data):
    outfile = open(file_path,"w+")
    for header in data.keys():
        print(header, file=outfile)
        print(data[header], file=outfile)
    outfile.close()

path_to_files = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/second_set/IMGT_GAP_fasta"
path_to_outfiles = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/second_set/IMGT_GAP_fasta_C_X_sub"
for file in os.listdir(path_to_files):
    file_path = path_to_files + "/" + file
    file_path_out = path_to_outfiles + "/" + file
    data = read_fasta_files(file_path)
    write_fasta_file(file_path_out,data)

