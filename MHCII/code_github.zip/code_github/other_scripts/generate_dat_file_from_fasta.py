import sys
import os
import math


def get_IDs_from_fasta(fasta_path):
    infile = open(fasta_path,"r")
    IDs = []
    for line in infile:
        if line[0] == ">":
            IDs.append(line[1:].strip())
    print(len(IDs))
    return IDs


def create_dat_file_from_IDS(path_to_IMGT_outfile,IDs):
    path_to_imgt_file = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/raw/imgt.dat"
    imgt_file = open(path_to_imgt_file,"r")
    number_of_lines_in_file = len(open(path_to_imgt_file).readlines())
    IMGT_outfile = open(path_to_IMGT_outfile,"w+")

    # Iterate through the IMGT.dat file
    entry = ""
    species_flag = False
    for i,line in enumerate(imgt_file):
        # Progress tracking
        if i%int(number_of_lines_in_file/10) == 0:
            print(math.ceil(i/number_of_lines_in_file*100),"%")
        
        line_split = line.strip().split()
        if len(line_split) >= 1:
            if line_split[0] == "ID":
                ID = line_split[1]
            if line_split[0] == "OS" and not species_flag:
                species = " ".join(line_split[1:])
                species_flag = True
            if line_split[0] != "//":
                entry += line
            
            else:
                if ID in IDs:
                    print(entry,file=IMGT_outfile)
                    print("//",file=IMGT_outfile)
                entry = ""
                species = ""
                species_flag = False
                ID = ""

fasta_path = "/Users/christianpederjacobsen/Dropbox/DTU/Civil/Master/1_semester/Special_project/code/data/IMGT_database/clean/after_redundancy/filtered_IMGT_ALL_germline_filtered.fasta"
outfile_path = fasta_path.replace(".fasta",".dat")

IDs = get_IDs_from_fasta(fasta_path)
create_dat_file_from_IDS(outfile_path,IDs)